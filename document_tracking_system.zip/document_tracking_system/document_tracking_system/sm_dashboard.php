<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'senior_manager') {
    header('Location: index.php');
    exit();
}
include 'config.php';
$dept = $_SESSION['department'];
$user_id = $_SESSION['user_id'];

$sql = "SELECT d.*, u.name as contractor_name 
        FROM documents d 
        JOIN users u ON d.contractor_id = u.id 
        WHERE d.forwarded_to = ? AND d.status = 'in_review'";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("SQL prepare failed: " . $conn->error);
}

$stmt->bind_param("i", $user_id);

if (!$stmt->execute()) {
    die("SQL execute failed: " . $stmt->error);
}

$result = $stmt->get_result();

if (!$result) {
    die("Getting result failed: " . $stmt->error);
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Senior Manager Dashboard</title>
    <style>
        body { font-family: Arial; background: lightgreen; }
        table { width: 100%; background: lightblue; border-collapse: collapse; }
        th, td { padding: 10px; border: 1px solid #ccc; }
        .btn-approve { background: purple; color: white; padding: 5px 10px; }
        .btn-reject { background: red; color: white; padding: 5px 10px; }
        .btn-paid { background: darkgreen; color: white; padding: 5px 10px; }
        .btn-complete { background: blue; color: white; padding: 5px 10px; }
        footer { position: fixed; bottom: 0; width: 100%; text-align: center; background: #eee; padding: 5px; }
    </style>
</head>
<body>
    <h2>Welcome Senior Manager (<?php echo $_SESSION['name']; ?>)</h2>
    <h3>Documents Ready for Action</h3>
    <table>
    <tr>
        <th>Title</th>
        <th>Category</th>
        <th>Contractor</th>
        <th>Assistant Manager Comment</th>
        <th>Document</th>
        <th>Action</th>
    </tr>
    <?php while($row = $result->fetch_assoc()) { ?>
    <tr>
        <td><?php echo htmlspecialchars($row['title']); ?></td>
        <td><?php echo htmlspecialchars($row['category']); ?></td>
        <td><?php echo htmlspecialchars($row['contractor_name']); ?></td>
        <td><?php echo nl2br(htmlspecialchars($row['comment'])); ?></td>
        <td>
            <?php if (!empty($row['file_name'])): ?>
                <a href="uploads/<?php echo htmlspecialchars($row['file_name']); ?>" target="_blank">View</a>
            <?php else: ?>
                No file uploaded
            <?php endif; ?>
        </td>
        <td>
            <form action="sm_action.php" method="post" style="display:inline;">
                <input type="hidden" name="doc_id" value="<?php echo $row['id']; ?>">
                <button class="btn-approve" name="action" value="approve">Approve</button>
                <button class="btn-reject" name="action" value="reject">Reject</button>
                <button class="btn-paid" name="action" value="paid">Mark Paid</button>
                <button class="btn-complete" name="action" value="complete">Complete</button>
            </form>
        </td>
    </tr>
    <?php } ?>
        </table>
    <footer>val@2025</footer>
</body>
</html>
