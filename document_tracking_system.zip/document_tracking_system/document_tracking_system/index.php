<!DOCTYPE html>
<html>
<head>
    <title>Login - Document Tracker</title>
    <style>
        body { font-family: Arial; background: lightgreen; color: #333; }
        .login-box { width: 300px; margin: auto; margin-top: 100px; padding: 20px; background: lightblue; border-radius: 10px; }
        footer { position: fixed; bottom: 0; width: 100%; text-align: center; background: #eee; padding: 5px; }
    </style>
</head>
<body>
    <div class="login-box">
        <form method="post" action="login.php">
            <h2>Login</h2>
            <label>Email:</label><br>
            <input type="text" name="email" required><br><br>
            <label>Password:</label><br>
            <input type="password" name="password" required><br><br>
            <button type="submit">Login</button>
        </form>
    </div>
    <footer>val@2025</footer>
</body>
</html>