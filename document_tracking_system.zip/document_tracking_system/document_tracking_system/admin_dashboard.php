
<?php
session_start();
include 'config.php';

// Ensure the user is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

// Get all users
$userSql = "SELECT id, name, role, department FROM users";
$userResult = $conn->query($userSql);

// Get all documents and their current department and contractor
$docSql = "
    SELECT d.id AS document_id, d.title, d.category, d.status, u.name AS contractor_name, 
           dh.department AS current_department, dh.timestamp AS last_updated
    FROM documents d 
    JOIN users u ON d.contractor_id = u.id
    JOIN document_history dh ON d.id = dh.document_id
    WHERE dh.is_current = 1  -- Only the most recent department for the document
";
$docResult = $conn->query($docSql);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body { font-family: Arial; background: lightgreen; }
        table { width: 100%; background: lightblue; }
        th, td { padding: 10px; border-bottom: 1px solid #ccc; }
        footer { text-align: center; background: #eee; padding: 5px; }
    </style>
</head>
<body>
    <h2>Admin Dashboard</h2>
    <p>Welcome, <?php echo $_SESSION['name']; ?>. You have access to all areas of the system.</p>
    
    <h3>Users</h3>
    <table>
        <tr>
            <th>User ID</th>
            <th>Name</th>
            <th>Role</th>
            <th>Department</th>
        </tr>
        <?php while($row = $userResult->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['role']; ?></td>
            <td><?php echo $row['department']; ?></td>
        </tr>
        <?php } ?>
    </table>

    <h3>Documents</h3>
    <table>
        <tr>
            <th>Document ID</th>
            <th>Title</th>
            <th>Category</th>
            <th>Status</th>
            <th>Contractor</th>
            <th>Current Department</th>
            <th>Last Updated</th>
        </tr>
        <?php while($row = $docResult->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['document_id']; ?></td>
            <td><?php echo $row['title']; ?></td>
            <td><?php echo $row['category']; ?></td>
            <td><?php echo $row['status']; ?></td>
            <td><?php echo $row['contractor_name']; ?></td>
            <td><?php echo $row['current_department']; ?></td>
            <td><?php echo $row['last_updated']; ?></td>
        </tr>
        <?php } ?>
    </table>   <br><br></br>

    <footer>val@2025</footer>
</body>
</html>
