<?php
// logout.php - Ends session and redirects
session_start();
session_destroy();
header("Location: index.php");
exit();
?>

<?php
// generate_qr.php - Generate QR code for document ID
require 'vendor/autoload.php';
use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;

function generateQRCode($documentId) {
    $qrCode = QrCode::create("Document ID: $documentId");
    $writer = new PngWriter();
    $result = $writer->write($qrCode);
    $path = 'qrcodes/doc_' . $documentId . '.png';
    file_put_contents($path, $result->getString());
    return $path;
}
?>