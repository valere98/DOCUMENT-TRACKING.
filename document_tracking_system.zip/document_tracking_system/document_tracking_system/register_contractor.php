<?php
include 'config.php';
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
$sql = "INSERT INTO users (name, email, password, role) VALUES ('$name', '$email', '$password', 'contractor')";
if ($conn->query($sql) === TRUE) {
    echo "Contractor registered successfully. <a href='clerk_dashboard.php'>Go back</a>";
} else {
    echo "Error: " . $conn->error;
}
?>