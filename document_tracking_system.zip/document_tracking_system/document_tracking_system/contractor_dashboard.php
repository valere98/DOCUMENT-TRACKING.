<?php
// contractor_dashboard.php - Contractor can view and download their documents
session_start();
include 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'contractor') {
    header("Location: index.php");
    exit();
}

$contractorId = $_SESSION['user_id'];
$sql = "SELECT d.*, u.name AS clerk_name FROM documents d JOIN users u ON d.clerk_id = u.id WHERE d.contractor_id = $contractorId";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Contractor Dashboard</title>
    <style>
        body { font-family: Arial; background: lightgreen; }
        table { width: 100%; background: lightblue; }
        th, td { padding: 10px; border-bottom: 1px solid #ccc; }
        footer { text-align: center; background: #eee; padding: 5px; }
    </style>
</head>
<body>
    <h2>Welcome, <?php echo $_SESSION['name']; ?></h2>
    <h3>Your Documents</h3>
    <table>
        <tr>
            <th>Title</th>
            <th>Category</th>
            <th>Status</th>
            <th>Uploaded By</th>
            <th>QR Code</th>
            <th>PDF</th>
        </tr>
        <?php while($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['title']; ?></td>
            <td><?php echo $row['category']; ?></td>
            <td><?php echo $row['status']; ?></td>
            <td><?php echo $row['clerk_name']; ?></td>
            <td><img src="<?php echo $row['qr_code_path']; ?>" width="50"></td>
            <td><a href="<?php echo $row['file_path']; ?>" download>Download</a></td>
        </tr>
        <?php } ?>
    </table>
    <footer>val@2025</footer>
</body>
</html>
