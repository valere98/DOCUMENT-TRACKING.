
<?php
session_start();
include 'config.php';

// Ensure required directories exist
if (!file_exists('uploads')) {
    mkdir('uploads', 0777, true);
}
if (!file_exists('qrcodes')) {
    mkdir('qrcodes', 0777, true);
}

if ($_FILES['pdf']['type'] == 'application/pdf') {
    $contractor_id = $_POST['contractor_id'];
    $title = $_POST['title'];
    $category = $_POST['category'];
    $final_department = $_POST['final_department'];
    $filename = uniqid() . ".pdf";
    $filepath = "uploads/" . $filename;

    // Automatically fetch assistant manager for the department
    $res = $conn->query("SELECT id FROM users WHERE role='assistant_manager' AND department='$final_department' LIMIT 1");
    if ($res && $res->num_rows > 0) {
        $am = $res->fetch_assoc();
        $assistant_manager_id = $am['id'];
    } else {
        die("No assistant manager found in the $final_department department. Please contact the administrator.");
    }

    if (move_uploaded_file($_FILES['pdf']['tmp_name'], $filepath)) {
        $qr_code = "qrcodes/" . uniqid() . ".png";
        include 'phpqrcode/qrlib.php';
        QRcode::png("Document: $title, ID: $filename, Dept: $final_department", $qr_code);

        $sql = "INSERT INTO documents (contractor_id, clerk_id, title, category, file_path, qr_code_path, final_department, forwarded_to, status) 
                VALUES ('$contractor_id', '{$_SESSION['user_id']}', '$title', '$category', '$filepath', '$qr_code', '$final_department', '$assistant_manager_id', 'uploaded')";

        if ($conn->query($sql)) {
            echo "Document uploaded and forwarded to assistant manager of $final_department department successfully. <a href='clerk_dashboard.php'>Back</a>";
        } else {
            echo "Upload failed: " . $conn->error;
        }
    } else {
        echo "Failed to move uploaded file.";
    }
} else {
    echo "Only PDF files allowed.";
}
?>
