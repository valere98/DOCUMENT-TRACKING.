
<?php
session_start();
include 'config.php';

$email = $_POST['email'];
$pass = $_POST['password'];

$sql = "SELECT * FROM users WHERE email='$email' AND password='$pass'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['name'] = $user['name'];
    $_SESSION['department'] = $user['department']; // ✅ Fix: Store department in session

    switch ($user['role']) {
        case 'admin': header("Location: admin_dashboard.php"); break;
        case 'clerk': header("Location: clerk_dashboard.php"); break;
        case 'contractor': header("Location: contractor_dashboard.php"); break;
        case 'assistant_manager': header("Location: am_dashboard.php"); break;
        case 'senior_manager': header("Location: sm_dashboard.php"); break;
        default: echo "Unknown role.";
    }
} else {
    echo "Login failed. <a href='index.php'>Try again</a>";
}
?>
