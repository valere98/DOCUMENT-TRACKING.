<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'assistant_manager') {
    header('Location: index.php');
    exit();
}

include 'config.php';

if (!isset($_SESSION['department'])) {
    die("Department not set. Please contact admin.");
}

$department = $_SESSION['department'];
$user_id = $_SESSION['user_id'];
$name = $_SESSION['name'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $doc_id = intval($_POST['doc_id']);
    $action = $_POST['action'];
    $comment = trim($_POST['comment']);

    // Check if document belongs to the assistant manager
    $check = $conn->prepare("SELECT id FROM documents WHERE id = ? AND forwarded_to = ?");
    $check->bind_param("ii", $doc_id, $user_id);
    $check->execute();
    $res = $check->get_result();

    if ($res->num_rows === 1) {
        if ($action === 'approve') {
            // Find senior manager in the same department
            $sm = $conn->prepare("SELECT id FROM users WHERE role='senior_manager' AND department=? LIMIT 1");
            $sm->bind_param("s", $department);
            $sm->execute();
            $sm_result = $sm->get_result();

            if ($sm_result->num_rows === 0) {
                die("No Senior Manager found for your department.");
            }

            $sm_id = $sm_result->fetch_assoc()['id'];
            $status = 'in_review';
            $stmt = $conn->prepare("UPDATE documents SET status=?, comment=?, forwarded_to=? WHERE id=?");
            if (!$stmt) {
                die("SQL Error: " . $conn->error);  // Will display the specific SQL error
            } 
            $stmt->bind_param("ssii", $status, $comment, $sm_id, $doc_id);
        } elseif ($action === 'reject') {
            $status = 'rejected';
            $stmt = $conn->prepare("UPDATE documents SET status=?, comment=? WHERE id=?");
            $stmt->bind_param("ssi", $status, $comment, $doc_id);
        } else {
            die("Invalid action.");
        }

        if ($stmt->execute()) {
            header("Location: am_dashboard.php?msg=$status");
            exit();
        } else {
            echo "Failed to update document.";
        }
    } else {
        echo "Unauthorized or document not found.";
    }
}

// Get documents assigned to this assistant manager
$doc_sql = "SELECT d.*, u.name AS contractor_name 
            FROM documents d 
            JOIN users u ON d.contractor_id = u.id 
            WHERE d.forwarded_to = ?";
$stmt = $conn->prepare($doc_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$docs = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Assistant Manager Dashboard</title>
    <style>
        body { font-family: Arial; background:rgb(76, 235, 76); }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 10px; text-align: left; }
        .btn-approve { background: green; color: white; padding: 5px 10px; }
        .btn-reject { background: red; color: white; padding: 5px 10px; }
    </style>
</head>
<body>
    <h2>Welcome, Assistant Manager <?php echo htmlspecialchars($name); ?></h2>

    <h3>Documents Awaiting Your Action</h3>
    <?php if ($docs->num_rows === 0): ?>
        <p>No documents found as of now !.</p>
    <?php else: ?>
        <table>
            <tr>
                <th>Title</th>
                <th>Category</th>
                <th>Contractor</th>
                <th>Comment</th>
                <th>Action</th>
            </tr>
            <?php while ($doc = $docs->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($doc['title']); ?></td>
                <td><?php echo htmlspecialchars($doc['category']); ?></td>
                <td><?php echo htmlspecialchars($doc['contractor_name']); ?></td>
                <td>
                    <form method="POST">
                        <input type="hidden" name="doc_id" value="<?php echo $doc['id']; ?>">
                        <textarea name="comment" required></textarea><br>
                        <button type="submit" name="action" value="approve" class="btn-approve">Approve & Forward</button>
                        <button type="submit" name="action" value="reject" class="btn-reject">Reject</button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    <?php endif; ?>
</body>
</html>
