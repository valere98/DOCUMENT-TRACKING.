
<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'clerk') {
    header('Location: index.php');
    exit();
}
include 'config.php';

// Fetch contractors
$contractors = $conn->query("SELECT id, name FROM users WHERE role = 'contractor'");

// Fetch uploaded documents
$documents = $conn->query("
    SELECT d.*, u.name AS contractor_name 
    FROM documents d 
    JOIN users u ON d.contractor_id = u.id 
    WHERE d.clerk_id = {$_SESSION['user_id']}
    ORDER BY d.id DESC
");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Clerk Dashboard</title>
    <style>
        body { font-family: Arial; background: lightgreen; padding: 20px; }
        h2 { color: #333; }
        .box { background: lightblue; padding: 20px; margin-bottom: 30px; border-radius: 10px; }
        label, select, input, button { display: block; margin-top: 10px; width: 100%; padding: 8px; }
        table { width: 100%; border-collapse: collapse; background: #fff; }
        th, td { border: 1px solid #ccc; padding: 10px; text-align: left; }
        th { background: #ddd; }
        img { width: 100px; }
        footer { text-align: center; margin-top: 40px; background: #eee; padding: 10px; }
    </style>
</head>
<body>
    <h2>Welcome, Clerk <?php echo htmlspecialchars($_SESSION['name']); ?></h2>

    <div class="box">
        <h3>Register Contractor</h3>
        <form method="post" action="register_contractor.php">
            <label>Name:</label>
            <input type="text" name="name" required>
            <label>Email:</label>
            <input type="email" name="email" required>
            <label>Password:</label>
            <input type="password" name="password" required>
            <button type="submit">Register</button>
        </form>
    </div>

    <div class="box">
        <h3>Upload Contractor Document</h3>
        <form method="post" action="upload_document.php" enctype="multipart/form-data">
            <label>Select Contractor:</label>
            <select name="contractor_id" required>
                <option value="">-- Choose Contractor --</option>
                <?php while ($row = $contractors->fetch_assoc()) { ?>
                    <option value="<?php echo $row['id']; ?>"><?php echo htmlspecialchars($row['name']); ?></option>
                <?php } ?>
            </select>

            <label>Title:</label>
            <input type="text" name="title" required>

            <label>Category:</label>
            <select name="category" required>
                <option value="invoice">Invoice</option>
                <option value="legal document">Legal Document</option>
                <option value="contract">Contract</option>
                <option value="receipt">Receipt</option>
                <option value="memo">Memo</option>
            </select>

            <label>Final Department:</label>
            <select name="final_department" required>
                <option value="">-- Select Department --</option>
                <option value="Finance">Finance</option>
                <option value="Legal">Legal</option>
                <option value="IT">IT</option>
                <option value="Procurement">Procurement</option>
            </select>

            <label>PDF File:</label>
            <input type="file" name="pdf" accept="application/pdf" required>

            <button type="submit">Upload Document</button>
        </form>
    </div>

    <div class="box">
        <h3>Documents You Have Uploaded</h3>
        <table>
            <tr>
                <th>Title</th>
                <th>Contractor</th>
                <th>Category</th>
                <th>Department</th>
                <th>PDF</th>
                <th>QR Code</th>
                <th>Status</th>
            </tr>
            <?php while ($doc = $documents->fetch_assoc()) { ?>
            <tr>
                <td><?php echo htmlspecialchars($doc['title']); ?></td>
                <td><?php echo htmlspecialchars($doc['contractor_name']); ?></td>
                <td><?php echo htmlspecialchars($doc['category']); ?></td>
                <td><?php echo htmlspecialchars($doc['final_department']); ?></td>
                <td><a href="<?php echo $doc['file_path']; ?>" target="_blank">View PDF</a></td>
                <td><img src="<?php echo $doc['qr_code_path']; ?>" alt="QR Code"></td>
                <td><?php echo htmlspecialchars($doc['status']); ?></td>
            </tr>
            <?php } ?>
        </table>
    </div>

    <footer>val@2025</footer>
</body>
</html>
