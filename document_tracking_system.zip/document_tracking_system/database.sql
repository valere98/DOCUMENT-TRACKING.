CREATE DATABASE doc_tracking;
USE doc_tracking;
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255),
    role ENUM('admin', 'clerk', 'contractor', 'assistant_manager', 'senior_manager'),
    department ENUM('finance', 'IT', 'legal', 'procurement') NULL
);
CREATE TABLE documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    contractor_id INT,
    clerk_id INT,
    title VARCHAR(255),
    category ENUM('invoice', 'legal', 'contract', 'receipt', 'memo'),
    file_path VARCHAR(255),
    status ENUM('uploaded', 'in_review', 'approved', 'rejected', 'completed', 'paid'),
    qr_code_path VARCHAR(255),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (contractor_id) REFERENCES users(id),
    FOREIGN KEY (clerk_id) REFERENCES users(id)
);
CREATE TABLE document_movements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    document_id INT,
    from_department ENUM('finance', 'IT', 'legal', 'procurement'),
    to_department ENUM('finance', 'IT', 'legal', 'procurement'),
    assigned_to INT,
    role ENUM('assistant_manager', 'senior_manager'),
    status ENUM('received', 'approved', 'rejected', 'paid', 'completed'),
    remarks TEXT,
    moved_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (document_id) REFERENCES documents(id),
    FOREIGN KEY (assigned_to) REFERENCES users(id)
);