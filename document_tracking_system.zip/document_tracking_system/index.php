
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - County Government Document Tracker</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f4f4f4;
        }

        header {
            background-color: #007a33;
            color: white;
            padding: 15px 20px;
            font-size: 20px;
            font-weight: bold;
        }

        header::before {
            content: "📄 ";
        }

        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 80vh;
        }

        .login-box {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }

        h2 {
            margin-bottom: 10px;
        }

        p {
            color: #666;
            margin-bottom: 30px;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        .checkbox {
            text-align: left;
            margin-bottom: 20px;
        }

        .checkbox label {
            font-size: 14px;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #218838;
        }

        a {
            font-size: 14px;
            text-decoration: none;
            color: #007bff;
        }

        a:hover {
            text-decoration: underline;
        }

        footer {
            background: #004d26;
            color: white;
            text-align: center;
            padding: 10px;
            font-size: 14px;
        }

        .input-icon {
            position: relative;
        }

        .input-icon input {
            padding-right: 30px;
        }

        .input-icon span {
            position: absolute;
            right: 10px;
            top: 12px;
            cursor: pointer;
            color: #999;
        }
    </style>
</head>
<body>

<header>County Gov Document Tracker</header>

<div class="login-container">
    <div class="login-box">
        <h2>Login to Your Account</h2>
        <p>Enter your credentials to access the document tracking system</p>
        <form method="post" action="login.php">
            <div class="input-icon">
                <input type="text" name="email" placeholder="your.email@example.com" required>
            </div>
            <div class="input-icon">
                <input type="password" name="password" placeholder="Password" required>
                <span onclick="togglePassword(this)">👁️</span>
            </div>
            <div class="checkbox">
                <label><input type="checkbox" name="remember"> Remember me</label>
            </div>
            <button type="submit">Sign in</button>
            <p><a href="#">Forgot your password?</a></p>
        </form>
    </div>
</div>

<footer>
    © 2025 (val) County Government Document Tracking System
</footer>

<script>
    function togglePassword(el) {
        const input = el.previousElementSibling;
        input.type = input.type === "password" ? "text" : "password";
    }
</script>

</body>
</html>
