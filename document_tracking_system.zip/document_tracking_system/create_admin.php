<?php
// create_admin.php - Script to create an admin user
include 'config.php';

// Check if the script has already been run by checking for existing admin users
$check_sql = "SELECT COUNT(*) as count FROM users WHERE role = 'admin'";
$result = $conn->query($check_sql);
$row = $result->fetch_assoc();

if ($row['count'] > 0) {
    die("Admin user already exists. For security reasons, this script can only be run once.");
}

// Admin user details
$name = "Admin";
$email = "admin@doctracking.com";
$password = "admin123"; // In a production environment, use a strong password
$role = "admin";

// Insert the admin user
$sql = "INSERT INTO users (name, email, password, role) VALUES ('$name', '$email', '$password', '$role')";

if ($conn->query($sql) === TRUE) {
    echo "Admin user created successfully.<br>";
    echo "Email: $email<br>";
    echo "Password: $password<br>";
    echo "<a href='index.php'>Go to login page</a>";
} else {
    echo "Error creating admin user: " . $conn->error;
}

// Close the connection
$conn->close();
?> 