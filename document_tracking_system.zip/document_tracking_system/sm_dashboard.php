<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'senior_manager') {
    header('Location: index.php');
    exit();
}
include 'config.php';
$dept = $_SESSION['department'];
$user_id = $_SESSION['user_id'];

$sql = "SELECT d.*, u.name as contractor_name 
        FROM documents d 
        JOIN users u ON d.contractor_id = u.id 
        WHERE d.forwarded_to = ? AND d.status = 'in_review'";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("SQL prepare failed: " . $conn->error);
}

$stmt->bind_param("i", $user_id);

if (!$stmt->execute()) {
    die("SQL execute failed: " . $stmt->error);
}

$result = $stmt->get_result();

if (!$result) {
    die("Getting result failed: " . $stmt->error);
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Senior Manager Dashboard</title>
    <style>
         body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: #f4f4f4;
        padding: 20px;
        margin: 0;
    }

    h2 {
        color: #333;
    }

    .box {
        background: #ffffff;
        padding: 25px;
        margin-bottom: 30px;
        border-radius: 12px;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
    }

    label,
    select,
    input,
    button {
        display: block;
        margin-top: 12px;
        width: 100%;
        padding: 10px;
        font-size: 15px;
        border: 1px solid #ccc;
        border-radius: 6px;
        box-sizing: border-box;
    }

    button {
        background-color: #28a745;
        color: white;
        border: none;
        font-weight: bold;
        cursor: pointer;
    }

    button:hover {
        background-color: #218838;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        background: #ffffff;
        margin-top: 20px;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.05);
    }

    th, td {
        border: 1px solid #e0e0e0;
        padding: 12px;
        text-align: left;
        font-size: 14px;
    }

    th {
        background-color: #007a33;
        color: white;
        font-weight: bold;
    }

    img {
        width: 100px;
    }

    footer {
        text-align: center;
        margin-top: 40px;
        background: #004d26;
        color: white;
        padding: 15px;
        font-size: 14px;
        border-top: 4px solid #28a745;
    }
        </style>
</head>
<body>
    <h2>Welcome Senior Manager (<?php echo $_SESSION['name']; ?>)</h2>
    <h3>Documents Ready for Action</h3>
    <table>
    <tr>
        <th>Title</th>
        <th>Category</th>
        <th>Contractor</th>
        <th>Assistant Manager Comment</th>
        <th>Document</th>
        <th>Action</th>
    </tr>
    <?php while($row = $result->fetch_assoc()) { ?>
    <tr>
        <td><?php echo htmlspecialchars($row['title']); ?></td>
        <td><?php echo htmlspecialchars($row['category']); ?></td>
        <td><?php echo htmlspecialchars($row['contractor_name']); ?></td>
        <td><?php echo nl2br(htmlspecialchars($row['comment'])); ?></td>
        <td>
            <?php if (!empty($row['file_name'])): ?>
                <a href="uploads/<?php echo htmlspecialchars($row['file_name']); ?>" target="_blank">View</a>
            <?php else: ?>
                No file uploaded
            <?php endif; ?>
        </td>
        <td>
            <form action="sm_action.php" method="post" style="display:inline;">
                <input type="hidden" name="doc_id" value="<?php echo $row['id']; ?>">
                <button class="btn-approve" name="action" value="approve">Approve</button>
                <button class="btn-reject" name="action" value="reject">Reject</button>
                <button class="btn-paid" name="action" value="paid">Mark Paid</button>
                <button class="btn-complete" name="action" value="complete">Complete</button>
            </form>
        </td>
    </tr>
    <?php } ?>
        </table> <br> <br> <br> <br> <br> <br><br> <br> <br> <br> <br> <br> <br> <br><br> 
    <footer>val@2025</footer>
</body>
</html>
