
<?php
session_start();
include 'config.php';

// Ensure the user is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

// Get all users
$userSql = "SELECT id, name, role, department FROM users";
$userResult = $conn->query($userSql);

// Get all documents and their current department and contractor
$docSql = "
     SELECT 
        d.id AS document_id, 
        d.title, 
        d.category, 
        d.status,
        
        u.name AS contractor_name
    FROM documents d
    LEFT JOIN users u ON d.contractor_id = u.id
    ORDER BY d.id DESC
";
$docResult = $conn->query($docSql);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: #f4f4f4;
        padding: 20px;
        margin: 0;
    }

    h2 {
        color: #333;
    }

    .box {
        background: #ffffff;
        padding: 25px;
        margin-bottom: 30px;
        border-radius: 12px;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
    }

    label,
    select,
    input,
    button {
        display: block;
        margin-top: 12px;
        width: 100%;
        padding: 10px;
        font-size: 15px;
        border: 1px solid #ccc;
        border-radius: 6px;
        box-sizing: border-box;
    }

    button {
        background-color: #28a745;
        color: white;
        border: none;
        font-weight: bold;
        cursor: pointer;
    }

    button:hover {
        background-color: #218838;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        background: #ffffff;
        margin-top: 20px;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.05);
    }

    th, td {
        border: 1px solid #e0e0e0;
        padding: 12px;
        text-align: left;
        font-size: 14px;
    }

    th {
        background-color: #007a33;
        color: white;
        font-weight: bold;
    }

    img {
        width: 100px;
    }

    footer {
        text-align: center;
        margin-top: 40px;
        background: #004d26;
        color: white;
        padding: 15px;
        font-size: 14px;
        border-top: 4px solid #28a745;
    }
    </style>
</head>
<body>
    <h2>Admin Dashboard</h2>
    <p>Welcome, <?php echo $_SESSION['name']; ?>. You have access to all areas of the system.</p>
    
    <h3>Users</h3>
    <table>
        <tr>
            <th>User ID</th>
            <th>Name</th>
            <th>Role</th>
            <th>Department</th>
        </tr>
        <?php while($row = $userResult->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['role']; ?></td>
            <td><?php echo $row['department']; ?></td>
        </tr>
        <?php } ?>
    </table>

    <h3>Documents</h3>
    <table>
        <tr>
            <th>Document ID</th>
            <th>Title</th>
            <th>Category</th>
            <th>Status</th>
            <th>Contractor</th>
            
            
        </tr>
        <?php while($row = $docResult->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['document_id']; ?></td>
            <td><?php echo $row['title']; ?></td>
            <td><?php echo $row['category']; ?></td>
            <td><?php echo $row['status']; ?></td>
            <td><?php echo $row['contractor_name']; ?></td>
            
            
        </tr>
        <?php } ?>
    </table>   <br><br></br>

    <footer>val@2025</footer>
</body>
</html>
