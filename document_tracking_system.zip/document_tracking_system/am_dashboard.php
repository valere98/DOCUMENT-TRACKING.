<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'assistant_manager') {
    header('Location: index.php');
    exit();
}

include 'config.php';

if (!isset($_SESSION['department'])) {
    die("Department not set. Please contact admin.");
}

$department = $_SESSION['department'];
$user_id = $_SESSION['user_id'];
$name = $_SESSION['name'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $doc_id = intval($_POST['doc_id']);
    $action = $_POST['action'];
    $comment = trim($_POST['comment']);

    // Check if document belongs to the assistant manager
    $check = $conn->prepare("SELECT id FROM documents WHERE id = ? AND forwarded_to = ?");
    $check->bind_param("ii", $doc_id, $user_id);
    $check->execute();
    $res = $check->get_result();

    if ($res->num_rows === 1) {
        if ($action === 'approve') {
            // Find senior manager in the same department
            $sm = $conn->prepare("SELECT id FROM users WHERE role='senior_manager' AND department=? LIMIT 1");
            $sm->bind_param("s", $department);
            $sm->execute();
            $sm_result = $sm->get_result();

            if ($sm_result->num_rows === 0) {
                die("No Senior Manager found for your department.");
            }

            $sm_id = $sm_result->fetch_assoc()['id'];
            $status = 'in_review';
            $stmt = $conn->prepare("UPDATE documents SET status=?, comment=?, forwarded_to=? WHERE id=?");
            if (!$stmt) {
                die("SQL Error: " . $conn->error);  // Will display the specific SQL error
            } 
            $stmt->bind_param("ssii", $status, $comment, $sm_id, $doc_id);
        } elseif ($action === 'reject') {
            $status = 'rejected';
            $stmt = $conn->prepare("UPDATE documents SET status=?, comment=? WHERE id=?");
            $stmt->bind_param("ssi", $status, $comment, $doc_id);
        } else {
            die("Invalid action.");
        }

        if ($stmt->execute()) {
            header("Location: am_dashboard.php?msg=$status");
            exit();
        } else {
            echo "Failed to update document.";
        }
    } else {
        echo "Unauthorized or document not found.";
    }
}

// Get documents assigned to this assistant manager
$doc_sql = "SELECT d.*, u.name AS contractor_name 
            FROM documents d 
            JOIN users u ON d.contractor_id = u.id 
            WHERE d.forwarded_to = ?";
$stmt = $conn->prepare($doc_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$docs = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Assistant Manager Dashboard</title>
    <style>
         body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: #f4f4f4;
        padding: 20px;
        margin: 0;
    }

    h2 {
        color: #333;
    }

    .box {
        background: #ffffff;
        padding: 25px;
        margin-bottom: 30px;
        border-radius: 12px;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
    }

    label,
    select,
    input,
    button {
        display: block;
        margin-top: 12px;
        width: 100%;
        padding: 10px;
        font-size: 15px;
        border: 1px solid #ccc;
        border-radius: 6px;
        box-sizing: border-box;
    }

    button {
        background-color: #28a745;
        color: white;
        border: none;
        font-weight: bold;
        cursor: pointer;
    }

    button:hover {
        background-color: #218838;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        background: #ffffff;
        margin-top: 20px;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.05);
    }

    th, td {
        border: 1px solid #e0e0e0;
        padding: 12px;
        text-align: left;
        font-size: 14px;
    }

    th {
        background-color: #007a33;
        color: white;
        font-weight: bold;
    }

    img {
        width: 100px;
    }

    footer {
        text-align: center;
        margin-top: 40px;
        background: #004d26;
        color: white;
        padding: 15px;
        font-size: 14px;
        border-top: 4px solid #28a745;
    }
    </style>
</head>
<body>
    <h2>Welcome, Assistant Manager <?php echo htmlspecialchars($name); ?></h2>

    <h3>Documents Awaiting Your Action</h3>
    <?php if ($docs->num_rows === 0): ?>
        <p>No documents found as of now !.</p>
    <?php else: ?>
        <table>
            <tr>
                <th>Title</th>
                <th>Category</th>
                <th>Contractor</th>
                <th>Comment</th>
                <th>Action</th>
            </tr>
            <?php while ($doc = $docs->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($doc['title']); ?></td>
                <td><?php echo htmlspecialchars($doc['category']); ?></td>
                <td><?php echo htmlspecialchars($doc['contractor_name']); ?></td>
                <td>
                    <form method="POST">
                        <input type="hidden" name="doc_id" value="<?php echo $doc['id']; ?>">
                        <textarea name="comment" required></textarea><br>
                        <button type="submit" name="action" value="approve" class="btn-approve">Approve & Forward</button>
                        <button type="submit" name="action" value="reject" class="btn-reject">Reject</button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    <?php endif; ?>
</body>
</html>
