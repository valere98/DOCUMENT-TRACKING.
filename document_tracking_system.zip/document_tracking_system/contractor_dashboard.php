<?php
// contractor_dashboard.php - Contractor can view and download their documents
session_start();
include 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'contractor') {
    header("Location: index.php");
    exit();
}

$contractorId = $_SESSION['user_id'];
$sql = "SELECT d.*, u.name AS clerk_name FROM documents d JOIN users u ON d.clerk_id = u.id WHERE d.contractor_id = $contractorId";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Contractor Dashboard</title>
    <style>
         body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: #f4f4f4;
        padding: 20px;
        margin: 0;
    }

    h2 {
        color: #333;
    }

    .box {
        background: #ffffff;
        padding: 25px;
        margin-bottom: 30px;
        border-radius: 12px;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
    }

    label,
    select,
    input,
    button {
        display: block;
        margin-top: 12px;
        width: 100%;
        padding: 10px;
        font-size: 15px;
        border: 1px solid #ccc;
        border-radius: 6px;
        box-sizing: border-box;
    }

    button {
        background-color: #28a745;
        color: white;
        border: none;
        font-weight: bold;
        cursor: pointer;
    }

    button:hover {
        background-color: #218838;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        background: #ffffff;
        margin-top: 20px;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.05);
    }

    th, td {
        border: 1px solid #e0e0e0;
        padding: 12px;
        text-align: left;
        font-size: 14px;
    }

    th {
        background-color: #007a33;
        color: white;
        font-weight: bold;
    }

    img {
        width: 100px;
    }

    footer {
        text-align: center;
        margin-top: 40px;
        background: #004d26;
        color: white;
        padding: 15px;
        font-size: 14px;
        border-top: 4px solid #28a745;
    }
    </style>
</head>
<body>
    <h2>Welcome, <?php echo $_SESSION['name']; ?></h2>
    <h3>Your Documents</h3>
    <table>
        <tr>
            <th>Title</th>
            <th>Category</th>
            <th>Status</th>
            <th>Uploaded By</th>
            <th>QR Code</th>
            <th>PDF</th>
        </tr>
        <?php while($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['title']; ?></td>
            <td><?php echo $row['category']; ?></td>
            <td><?php echo $row['status']; ?></td>
            <td><?php echo $row['clerk_name']; ?></td>
            <td><img src="<?php echo $row['qr_code_path']; ?>" width="50"></td>
            <td><a href="<?php echo $row['file_path']; ?>" download>Download</a></td>
        </tr>
        <?php } ?>
    </table>
    <footer>val@2025</footer>
</body>
</html>
