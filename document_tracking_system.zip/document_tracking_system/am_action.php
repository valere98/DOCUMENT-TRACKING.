
<?php
session_start();
include 'config.php';
$doc_id = $_POST['doc_id'];
$action = $_POST['action'];
$status = ($action == 'approve') ? 'approved' : 'rejected';
$sql = "UPDATE documents SET status='$status' WHERE id='$doc_id'";
if ($conn->query($sql)) {
    echo "Document $status. <a href='am_dashboard.php'>Back</a>";
} else {
    echo "Failed: " . $conn->error;
}
?>
